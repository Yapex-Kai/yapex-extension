// Mark the extension installation by setting an attribute on the html element
document.documentElement.setAttribute('yapex-extension-installed', true); 